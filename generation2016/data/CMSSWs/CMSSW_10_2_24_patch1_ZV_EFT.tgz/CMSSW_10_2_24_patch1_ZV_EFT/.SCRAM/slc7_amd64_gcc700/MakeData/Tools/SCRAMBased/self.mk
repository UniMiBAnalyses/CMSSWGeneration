ifeq ($(strip $(FWCore/Version)),)
FWCoreVersion := self/FWCore/Version
FWCore/Version := FWCoreVersion
FWCoreVersion_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
FWCoreVersion_EX_USE := $(foreach d, self cmssw ,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
FWCoreVersion_EX_LIB   := FWCoreVersion
ALL_EXTERNAL_PRODS += FWCoreVersion
FWCoreVersion_CLASS := LIBRARY
FWCore/Version_relbigobj+=FWCoreVersion
endif
ifeq ($(strip $(FastSimulationSimplifiedGeometryPropagatorAuto)),)
FastSimulationSimplifiedGeometryPropagatorAuto := self/src/FastSimulation/SimplifiedGeometryPropagator/plugins
FastSimulationSimplifiedGeometryPropagatorAuto_LOC_USE := self cmssw FWCore/Framework FWCore/PluginManager FWCore/ParameterSet SimGeneral/HepPDTRecord TrackingTools/DetLayers TrackingTools/TrajectoryState TrackingTools/GeomPropagators RecoTracker/DeDx SimDataFormats/EncodedEventId FastSimulation/TrajectoryManager FastSimulation/SimplifiedGeometryPropagator FastSimulation/Calorimetry FastSimulation/CaloGeometryTools FastSimulation/ShowerDevelopment Geometry/Records Geometry/CaloGeometry DataFormats/Math hepmc clhep
ALL_EXTERNAL_PLUGIN_PRODS += FastSimulationSimplifiedGeometryPropagatorAuto
FastSimulation/SimplifiedGeometryPropagator_relbigobj+=FastSimulationSimplifiedGeometryPropagatorAuto
endif
ifeq ($(strip $(FastSimulation/SimplifiedGeometryPropagator)),)
FastSimulationSimplifiedGeometryPropagator := self/FastSimulation/SimplifiedGeometryPropagator
FastSimulation/SimplifiedGeometryPropagator := FastSimulationSimplifiedGeometryPropagator
FastSimulationSimplifiedGeometryPropagator_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
FastSimulationSimplifiedGeometryPropagator_EX_USE := $(foreach d, self cmssw FWCore/Framework FWCore/ParameterSet FWCore/Utilities FWCore/PluginManager TrackingTools/DetLayers TrackingTools/TrajectoryState TrackingTools/GeomPropagators DataFormats/GeometrySurface DataFormats/GeometryVector SimDataFormats/TrackingHit SimDataFormats/Track SimDataFormats/Vertex SimDataFormats/EncodedEventId Geometry/CommonDetUnit Geometry/Records Geometry/CaloGeometry CondFormats/External DataFormats/Math MagneticField/Engine MagneticField/Records FastSimulation/TrajectoryManager FastSimulation/Calorimetry FastSimulation/CaloGeometryTools FastSimulation/ShowerDevelopment RecoTracker/Record RecoTracker/TkDetLayers FWCore/ServiceRegistry GeneratorInterface/Pythia8Interface pythia8 heppdt clhep rootcore,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
FastSimulationSimplifiedGeometryPropagator_EX_LIB   := FastSimulationSimplifiedGeometryPropagator
ALL_EXTERNAL_PRODS += FastSimulationSimplifiedGeometryPropagator
FastSimulationSimplifiedGeometryPropagator_CLASS := LIBRARY
FastSimulation/SimplifiedGeometryPropagator_relbigobj+=FastSimulationSimplifiedGeometryPropagator
endif
ifeq ($(strip $(PhysicsTools/NanoAOD)),)
src_PhysicsTools_NanoAOD := self/PhysicsTools/NanoAOD
PhysicsTools/NanoAOD  := src_PhysicsTools_NanoAOD
src_PhysicsTools_NanoAOD_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
src_PhysicsTools_NanoAOD_EX_USE := $(foreach d, DataFormats/NanoAOD boost DataFormats/Common self cmssw DataFormats/Candidate fastjet-contrib fastjet DataFormats/StdDictionaries FWCore/Common FWCore/Utilities,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += src_PhysicsTools_NanoAOD
endif

ifeq ($(strip $(PhysicsToolsNanoAODPlugins)),)
PhysicsToolsNanoAODPlugins := self/src/PhysicsTools/NanoAOD/plugins
PhysicsToolsNanoAODPlugins_LOC_USE := self cmssw PhysicsTools/TensorFlow FWCore/Framework FWCore/ParameterSet FWCore/ServiceRegistry FWCore/Utilities DataFormats/Candidate DataFormats/PatCandidates CommonTools/Utils RecoEgamma/EgammaTools PhysicsTools/JetMCUtils DataFormats/NanoAOD roothistmatrix RecoVertex/VertexTools RecoVertex/VertexPrimitives DataFormats/L1TGlobal IOPool/Provenance DQMServices/Core CondFormats/BTauObjects CondTools/BTau fastjet fastjet-contrib
ALL_EXTERNAL_PLUGIN_PRODS += PhysicsToolsNanoAODPlugins
PhysicsTools/NanoAOD_relbigobj+=PhysicsToolsNanoAODPlugins
endif
