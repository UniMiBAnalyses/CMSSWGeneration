FastSimulationSimplifiedGeometryPropagatorAuto_PACKAGE := self/src/FastSimulation/SimplifiedGeometryPropagator/plugins
PhysicsToolsNanoAODPlugins_PACKAGE := self/src/PhysicsTools/NanoAOD/plugins
runtestPhysicsToolsNanoAOD_PACKAGE := self/src/PhysicsTools/NanoAOD/test
FastSimulationSimplifiedGeometryPropagator_PACKAGE := self/src/FastSimulation/SimplifiedGeometryPropagator/src
FWCoreVersion_PACKAGE := self/src/FWCore/Version/src
