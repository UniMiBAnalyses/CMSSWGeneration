__path__.append('/cvmfs/cms.cern.ch/slc7_amd64_gcc700/cms/cmssw-patch/CMSSW_10_2_24_patch1/python/PhysicsTools')
