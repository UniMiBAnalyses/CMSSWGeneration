ifeq ($(strip $(runtestPhysicsToolsNanoAOD)),)
runtestPhysicsToolsNanoAOD := self/src/PhysicsTools/NanoAOD/test
runtestPhysicsToolsNanoAOD_files := $(patsubst src/PhysicsTools/NanoAOD/test/%,%,$(foreach file,runtestPhysicsToolsNanoAOD.cpp,$(eval xfile:=$(wildcard src/PhysicsTools/NanoAOD/test/$(file)))$(if $(xfile),$(xfile),$(warning No such file exists: src/PhysicsTools/NanoAOD/test/$(file). Please fix src/PhysicsTools/NanoAOD/test/BuildFile.))))
runtestPhysicsToolsNanoAOD_TEST_RUNNER_CMD :=  runtestPhysicsToolsNanoAOD  /bin/bash PhysicsTools/NanoAOD/test runtests.sh
runtestPhysicsToolsNanoAOD_BuildFile    := $(WORKINGDIR)/cache/bf/src/PhysicsTools/NanoAOD/test/BuildFile
runtestPhysicsToolsNanoAOD_LOC_USE := self cmssw FWCore/Utilities
runtestPhysicsToolsNanoAOD_PACKAGE := self/src/PhysicsTools/NanoAOD/test
ALL_PRODS += runtestPhysicsToolsNanoAOD
runtestPhysicsToolsNanoAOD_INIT_FUNC        += $$(eval $$(call Binary,runtestPhysicsToolsNanoAOD,src/PhysicsTools/NanoAOD/test,src_PhysicsTools_NanoAOD_test,$(SCRAMSTORENAME_BIN),,$(SCRAMSTORENAME_TEST),test,$(SCRAMSTORENAME_LOGS)))
runtestPhysicsToolsNanoAOD_CLASS := TEST
else
$(eval $(call MultipleWarningMsg,runtestPhysicsToolsNanoAOD,src/PhysicsTools/NanoAOD/test))
endif
ALL_COMMONRULES += src_PhysicsTools_NanoAOD_test
src_PhysicsTools_NanoAOD_test_parent := PhysicsTools/NanoAOD
src_PhysicsTools_NanoAOD_test_INIT_FUNC += $$(eval $$(call CommonProductRules,src_PhysicsTools_NanoAOD_test,src/PhysicsTools/NanoAOD/test,TEST))
ALL_PACKAGES += PhysicsTools/NanoAOD
subdirs_src_PhysicsTools_NanoAOD := src_PhysicsTools_NanoAOD_test src_PhysicsTools_NanoAOD_plugins src_PhysicsTools_NanoAOD_interface src_PhysicsTools_NanoAOD_python
ALL_SUBSYSTEMS+=PhysicsTools
subdirs_src_PhysicsTools = src_PhysicsTools_NanoAOD
ifeq ($(strip $(PyPhysicsToolsNanoAOD)),)
PyPhysicsToolsNanoAOD := self/src/PhysicsTools/NanoAOD/python
src_PhysicsTools_NanoAOD_python_parent := 
ALL_PYTHON_DIRS += $(patsubst src/%,%,src/PhysicsTools/NanoAOD/python)
PyPhysicsToolsNanoAOD_files := $(patsubst src/PhysicsTools/NanoAOD/python/%,%,$(wildcard $(foreach dir,src/PhysicsTools/NanoAOD/python ,$(foreach ext,$(SRC_FILES_SUFFIXES),$(dir)/*.$(ext)))))
PyPhysicsToolsNanoAOD_LOC_USE := self cmssw 
PyPhysicsToolsNanoAOD_PACKAGE := self/src/PhysicsTools/NanoAOD/python
ALL_PRODS += PyPhysicsToolsNanoAOD
PyPhysicsToolsNanoAOD_INIT_FUNC        += $$(eval $$(call PythonProduct,PyPhysicsToolsNanoAOD,src/PhysicsTools/NanoAOD/python,src_PhysicsTools_NanoAOD_python,1,1,$(SCRAMSTORENAME_PYTHON),$(SCRAMSTORENAME_LIB),,))
else
$(eval $(call MultipleWarningMsg,PyPhysicsToolsNanoAOD,src/PhysicsTools/NanoAOD/python))
endif
ALL_COMMONRULES += src_PhysicsTools_NanoAOD_python
src_PhysicsTools_NanoAOD_python_INIT_FUNC += $$(eval $$(call CommonProductRules,src_PhysicsTools_NanoAOD_python,src/PhysicsTools/NanoAOD/python,PYTHON))
