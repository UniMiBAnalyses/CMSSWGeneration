ALL_TOOLS      += lcov

