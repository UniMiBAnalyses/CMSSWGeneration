ALL_TOOLS      += pyqt

